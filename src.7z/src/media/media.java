/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package media;

/**
 *
 * @author hkom
 */
public class media {
    
}
