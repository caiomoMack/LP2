/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package media;

/**
 *
 * @author hkom
 */
public class calculoMedia {
    private int nota1;
    private int nota2;
    
    public calculoMedia(int nota1,int nota2){
        this.nota1 = nota1;
        this.nota2 = nota2;
    }
    
    
}
